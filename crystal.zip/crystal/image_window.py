import os
from PyQt5.QtWidgets import QMainWindow, QVBoxLayout, QLabel, QTextEdit, QWidget, QFileDialog, QPushButton
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt,QTimer
from .image_processing import spot_detection
from .utils import get_image_files, convert_image_for_display, update_info_box

class ImageWindow(QMainWindow):
    def __init__(self, area_window, elongation_window):
        super().__init__()

        self.area_window = area_window
        self.elongation_window = elongation_window

        self.setWindowTitle("晶体图像分析")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        self.imageLabel = QLabel(self)
        layout.addWidget(self.imageLabel)

        self.infoBox = QTextEdit(self)
        layout.addWidget(self.infoBox)

        self.openDirectoryButton = QPushButton("打开文件夹", self)
        self.openDirectoryButton.clicked.connect(self.load_images)
        layout.addWidget(self.openDirectoryButton)

        self.exitButton = QPushButton("退出", self)
        self.exitButton.clicked.connect(self.close_application)
        layout.addWidget(self.exitButton)

        centralWidget = QWidget()
        centralWidget.setLayout(layout)
        self.setCentralWidget(centralWidget)

        self.current_folder = None
        self.images = []
        self.current_index = -1
        self.area_data = {'bright_l': [], 'bright_m': [], 'bright_r': []}
        self.elongation_data = {'bright_l': [], 'bright_m': [], 'bright_r': []}
        self.processed_images = set()

        # 定时器用于定期检查文件夹
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.check_for_new_images)
        self.timer.start(100)  

    def close_application(self):
        '''
        退出软件
        '''
        if self.area_window is not None:
            self.area_window.close()
        if self.elongation_window is not None:
            self.elongation_window.close()

        self.close()

    def load_images(self):
        folder_path = QFileDialog.getExistingDirectory(self, "Select Image Directory")
        # folder_path = './data/test'
        if not folder_path:
            return

        self.current_folder = folder_path
        self.images = get_image_files(folder_path)
        self.current_index = -1  # 重置索引

        if self.images:
            self.display_next_image()

    def display_next_image(self):
        '''
        自动递归更新下一张图片
        '''
        self.current_index += 1
        if self.current_index < len(self.images):
            self.show_image(self.images[self.current_index])
            QTimer.singleShot(500, self.display_next_image)  


    def check_for_new_images(self):
        if not self.current_folder:
            return

        new_images = get_image_files(self.current_folder)
        if not new_images:
            return

        if len(new_images) > len(self.images):
            for new_image in new_images[len(self.images):]:
                self.images.append(new_image)
                self.show_image(new_image)

    def show_image(self, image_path):
        self.infoBox.clear()

        image, info, image_name = spot_detection(image_path)
        pixmap = convert_image_for_display(image)

        self.setWindowTitle(image_name)
        self.imageLabel.setPixmap(pixmap)
        self.imageLabel.adjustSize()

        update_info_box(self.infoBox, info, self.area_data, self.elongation_data)

        if image_path not in self.processed_images: 
            self.processed_images.add(image_path)  
            self.area_window.update_plot(self.area_data)  
            self.elongation_window.update_plot(self.elongation_data)